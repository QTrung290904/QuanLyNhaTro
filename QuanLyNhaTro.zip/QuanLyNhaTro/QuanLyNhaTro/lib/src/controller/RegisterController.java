package controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import model.Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class RegisterController {
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private TextField fullNameField;

    public void handleRegister() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();
        String fullName = fullNameField.getText().trim();

        if (username.isEmpty() || password.isEmpty()) {
            showAlert("❗ Vui lòng nhập đầy đủ thông tin!", Alert.AlertType.WARNING);
            return;
        }

        try (Connection conn = Database.connect()) {
            // Kiểm tra trùng username
            PreparedStatement checkStmt = conn.prepareStatement("SELECT * FROM users WHERE username = ?");
            checkStmt.setString(1, username);
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next()) {
                showAlert("❌ Tên đăng nhập đã tồn tại!", Alert.AlertType.ERROR);
                return;
            }

            // Thêm user mới
            PreparedStatement insertStmt = conn.prepareStatement("INSERT INTO users (username, password_hash, full_name) VALUES (?, ?, ?)");
            insertStmt.setString(1, username);
            insertStmt.setString(2, password); // 🚨 Thực tế nên mã hóa
            insertStmt.setString(3, fullName);
            insertStmt.executeUpdate();

            showAlert("✅ Đăng ký thành công!", Alert.AlertType.INFORMATION);
            SceneSwitcher.switchScene("login.fxml");
        } catch (Exception e) {
            showAlert("❌ Lỗi kết nối: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    public void handleBackToLogin() {
        SceneSwitcher.switchScene("login.fxml");
    }

    private void showAlert(String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
